from django.shortcuts import render,HttpResponse
from home.models import Task, Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate



def index(request):   
    if request.user.is_anonymous:
        return render(request, 'login.html')

    if request.method == "POST":
        taskTitle= request.POST.get('taskTitle')
        taskDesc= request.POST.get('taskDesc')
        task = Task(taskTitle=taskTitle, taskDesc=taskDesc)
        task.save()
        messages.success(request, "Your Task has been successfully submitted!")
    return render(request, 'index.html')

def contact(request):
    if request.method =="POST":
        name= request.POST.get('name')
        email= request.POST.get('email')
        phone= request.POST.get('phone')
        desc= request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
        messages.success(request, "Thank you for getting in touch with us. Your query has been successfully submitted!")
    return render(request,'contact.html')

def task(request):
    if request.user.is_anonymous:
        return render(request, 'login.html')
         
    allTask = Task.objects.all()
    context = {'task': allTask}
    return render(request,'task.html',context)

def about(request):
    return render(request, 'about.html')

def loginuser(request):
    if request.method == "POST":
        username= request.POST.get('username')
        userpassword= request.POST.get('password')
        user = authenticate(username=username, password=userpassword)
        if user is not None:
            login(request, user)
            messages.success(request, "You are successfully login!")
            return render(request, 'index.html')
        
        else:
            messages.warning(request, "Please enter the correct username and password!")
            return render(request, 'login.html')
            

    return render(request, 'login.html')

def logoutuser(request):
    logout(request)
    messages.success(request, "You are successfully logout!")
    if request.user.is_anonymous:
        return render(request, 'login.html')
    return render(request, 'index.html')
 